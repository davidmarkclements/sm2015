"use strict";

require('seneca')()
  .use('sales-tax-plugin')
  .listen();
