"use strict";

var foo = "bar"

console.log("first:"+foo)

debugger;

console.log("second:"+foo)

