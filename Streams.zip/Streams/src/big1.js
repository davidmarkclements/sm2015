var request = require('request');
var JSONStream = require('JSONStream');

request('http://registry.npmjs.org/-/all')
  .pipe(JSONStream.parse('*.name', function (name) { 
  	return name + '\n'; 
  }))
  .pipe(process.stdout)