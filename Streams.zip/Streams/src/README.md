nodejsdublin-jun-2014
=====================

Example code for NodeJSDublin Talk June 2014.

See NodeJSDublin-Jun.pdf for step-by-step instructions.


# Installation

Visit [nodejs.org](http://nodejs.org) and install Node.js. 

Clone this repository to your local machine:

```bash
$ git clone https://github.com/rjrodger/nodejsdublin-jun-2014.git
```

Change directory into the project folder:
```bash
$ cd nodejsdublin-jun-2014
```

Then install the dependent modules:

```bash
$ npm install
```

And you're good to go!

Feel free to contact me on twitter if you have any questions! :) [@rjrodger](http://twitter.com/rjrodger)
